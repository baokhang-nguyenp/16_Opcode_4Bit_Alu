// ========================================================
// Module Name:  flag_unit
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps

module flag_unit (
    input  wire [3:0] opcode,
    input  wire       arith, is_shl, is_shr, is_mul, is_div,
    input  wire [7:0] result,
    input  wire       c3, c4, shl_bit, shr_bit, md_dbz,
    output reg        carry,
    output wire       zero, overflow, negative, div_by_zero
);
    always @(*) begin
        if (arith)       carry = c4;
        else if (is_shl) carry = shl_bit;
        else if (is_shr) carry = shr_bit;
        else             carry = 1'b0;
    end

    assign zero        = ~(|result);
    assign overflow    = arith & (c3 ^ c4);
    assign negative    = is_mul ? result[7] : result[3];
    assign div_by_zero = is_div & md_dbz;
endmodule