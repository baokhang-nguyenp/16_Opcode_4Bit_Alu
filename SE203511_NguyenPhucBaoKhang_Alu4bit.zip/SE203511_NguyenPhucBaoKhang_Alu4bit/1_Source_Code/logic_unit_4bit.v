// ========================================================
// Module Name:  logic_unit_4bit
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps
module logic_unit_4bit (
    input  wire [3:0] a, b,
    output wire [3:0] and_out, or_out, xor_out, not_out,
    output wire [3:0] nand_out, nor_out, xnor_out,
    output wire [7:0] dec_out
);
    assign and_out  = a & b;
    assign or_out   = a | b;
    assign xor_out  = a ^ b;
    assign not_out  = ~a;
    
    assign nand_out = ~(a & b);
    assign nor_out  = ~(a | b);
    assign xnor_out = ~(a ^ b);
    
    // Decoder 3-to-8: a[2:0] in signal, b[0]: Enable
    assign dec_out  = b[0] ? (8'b0000_0001 << a[2:0]) : 8'b0000_0000;
endmodule