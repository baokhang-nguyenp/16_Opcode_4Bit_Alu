// ========================================================
// Module Name:  alu_4bit_tb
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps

module alu_4bit_tb();
    reg clk, rst, start;
    reg [3:0] a, b, opcode;
    wire [7:0] result;
    wire carry, zero, overflow, negative, div_by_zero, busy, done;

    alu_4bit dut (.*);

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    reg [7:0] exp_r;
    integer   op_i, i_val, j_val;
    integer   errors = 0;

    task print_case(input [3:0] op, input [3:0] in_a, input [3:0] in_b, input string name);
        integer start_time, end_time, cycles;
        opcode = op; a = in_a; b = in_b; start = 1;
        @(negedge clk);
        start = 0;
        start_time = $time;
        
        if (op == 14 || op == 15) begin
            wait(done);
            @(negedge clk);
            end_time = $time;
            cycles = (end_time - start_time) / 10;
            
            if (op == 14)
                $display(" %s %b | %2d  %2d | %b (%3d) | product = %0d, %0d cycles",
                         name, op, in_a, in_b, result, result, result, cycles);
            else
                $display(" %s %b | %2d  %2d | %b        | quotient = %0d, remainder = %0d, dbz=%b, %0d cycles",
                         name, op, in_a, in_b, result, result[3:0], result[7:4], div_by_zero, cycles);
        end else begin
            $display(" %s %b | %2d  %2d | %b (%3d) | C=%b Z=%b V=%b N=%b",
                     name, op, in_a, in_b, result, result, carry, zero, overflow, negative);
        end
    endtask

    initial begin
        $display("========================================");
        $display("Student Name: Nguyen Phuc Bao Khang");
        $display("Roll Number: SE203511");
        $display("Project: 16-Opcode ALU (Verbose & Table)");
        $display("========================================");

        rst = 1; start = 0; 
        opcode = 4'b0000; a = 4'd5; b = 4'd3; 
        #20 rst = 0;

        $display("\n Op  code |  A   B |  result        | flags / notes");
        $display("----------+--------+----------------+------------------------------");
        print_case(4'b0000, 5,  3, "ADD ");
        print_case(4'b0000, 15, 1, "ADD ");
        print_case(4'b0001, 5,  3, "SUB ");
        print_case(4'b0001, 3,  5, "SUB ");
        print_case(4'b0010, 12, 10,"AND ");
        print_case(4'b0011, 12, 10,"OR  ");
        print_case(4'b0100, 12, 10,"XOR ");
        print_case(4'b0101, 12, 0, "NOT ");
        print_case(4'b1000, 11, 0, "SHL ");
        print_case(4'b1001, 11, 0, "SHR ");
        print_case(4'b1110, 13, 11,"MUL ");
        print_case(4'b1110, 15, 15,"MUL ");
        print_case(4'b1111, 13, 4, "DIV ");
        print_case(4'b1111, 15, 3, "DIV ");
        print_case(4'b1111, 9,  0, "DIV ");
        $display("----------+--------+----------------+------------------------------\n");

        for (op_i = 0; op_i < 16; op_i++) begin
            for (i_val = 0; i_val < 16; i_val++) begin
                for (j_val = 0; j_val < 16; j_val++) begin
                    @(negedge clk);
                    opcode = op_i; a = i_val; b = j_val; start = 1;
                    
                    @(negedge clk);
                    start = 0;

                    if (op_i == 14 || op_i == 15) begin
                        wait(done);
                        @(negedge clk);
                    end

                    case (op_i)
                        0:  exp_r = {4'b0000, (i_val[3:0] + j_val[3:0])};
                        1:  exp_r = {4'b0000, (i_val[3:0] - j_val[3:0])};
                        2:  exp_r = {4'b0000, (i_val[3:0] & j_val[3:0])};
                        3:  exp_r = {4'b0000, (i_val[3:0] | j_val[3:0])};
                        4:  exp_r = {4'b0000, (i_val[3:0] ^ j_val[3:0])};
                        5:  exp_r = {4'b0000, ~(i_val[3:0])};
                        6:  exp_r = {4'b0000, ~(i_val[3:0] & j_val[3:0])};
                        7:  exp_r = {4'b0000, ~(i_val[3:0] | j_val[3:0])};
                        8:  exp_r = {4'b0000, i_val[2:0], 1'b0};
                        9:  exp_r = {4'b0000, 1'b0, i_val[3:1]};
                        10: exp_r = {4'b0000, i_val[2:0], i_val[3]};
                        11: exp_r = {4'b0000, i_val[0], i_val[3:1]};
                        12: exp_r = {5'b00000, (i_val > j_val), (i_val == j_val), (i_val < j_val)};
                        13: exp_r = j_val[0] ? (8'b0000_0001 << i_val[2:0]) : 8'b0;
                        14: exp_r = i_val * j_val;
                        15: exp_r = (j_val == 0) ? 8'b0000_0000 : { 4'(i_val % j_val), 4'(i_val / j_val) };
                    endcase

                    if (result !== exp_r) begin
                        $display("FAIL: Op=%d A=%d B=%d | Exp=%b Act=%b", op_i, i_val, j_val, exp_r, result);
                        errors++;
                    end
                end
            end
        end
        
        if (errors == 0) $display("PASS: All 4096 checks completed, 0 errors");
        else $display("FAILED: %d errors", errors);
        
        $finish;
    end
endmodule