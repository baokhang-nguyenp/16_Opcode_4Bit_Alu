// ========================================================
// Module Name:  control_unit
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps
module control_unit (
    input  wire [3:0] opcode,
    output reg        sub, arith, is_shl, is_shr, is_mul, is_div,
    output wire       is_muldiv
);
    always @(*) begin
        sub    = 1'b0;
        arith  = 1'b0;
        is_shl = 1'b0;
        is_shr = 1'b0;
        is_mul = 1'b0;
        is_div = 1'b0;

        case (opcode)
            4'b0000: arith = 1'b1;                          // ADD
            4'b0001: begin sub = 1'b1; arith = 1'b1; end    // SUB
            4'b1000: is_shl = 1'b1;                         // SHL
            4'b1001: is_shr = 1'b1;                         // SHR
            4'b1110: is_mul = 1'b1;                         // MUL
            4'b1111: is_div = 1'b1;                         // DIV
            default: ; 
        endcase
    end
    assign is_muldiv = is_mul | is_div;
endmodule