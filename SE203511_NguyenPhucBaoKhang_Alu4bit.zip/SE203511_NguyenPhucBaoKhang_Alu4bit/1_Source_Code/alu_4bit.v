// ========================================================
// Module Name:  alu_4bit
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps
module alu_4bit (
    input  wire       clk, rst, start,
    input  wire [3:0] a, b, opcode,
    output wire [7:0] result,
    output wire       carry, zero, overflow, negative, div_by_zero, busy, done
);
    wire sub, arith, is_shl, is_shr, is_mul, is_div, is_muldiv;
    wire [3:0] add_a, add_b, sum;
    wire add_sub, c3, c4;
    wire [2:0] cmp_out;
    wire [3:0] and_out, or_out, xor_out, not_out, nand_out, nor_out, xnor_out;
    wire [7:0] dec_out;
    wire [3:0] shl, shr, rol, ror;
    wire shl_bit, shr_bit;
    wire [3:0] md_add_a, md_add_b;
    wire md_add_sub, md_dbz;
    wire [7:0] md_out;

    control_unit u_ctrl (
        .opcode(opcode), .sub(sub), .arith(arith), .is_shl(is_shl), .is_shr(is_shr),
        .is_mul(is_mul), .is_div(is_div), .is_muldiv(is_muldiv)
    );

    assign add_a   = busy ? md_add_a   : a;
    assign add_b   = busy ? md_add_b   : b;
    assign add_sub = busy ? md_add_sub : sub;

    adder_subtractor_4bit u_addsub (
        .a(add_a), .b(add_b), .sub(add_sub), .sum(sum), .c3(c3), .c4(c4), .cmp_out(cmp_out)
    );

    logic_unit_4bit u_logic (
        .a(a), .b(b), .and_out(and_out), .or_out(or_out), .xor_out(xor_out), .not_out(not_out),
        .nand_out(nand_out), .nor_out(nor_out), .xnor_out(xnor_out), .dec_out(dec_out)
    );

    shifter_4bit u_shift (
        .a(a), .shl(shl), .shr(shr), .rol(rol), .ror(ror),
        .shl_out_bit(shl_bit), .shr_out_bit(shr_bit)
    );

    muldiv_unit u_muldiv (
        .clk(clk), .rst(rst), .start(start & is_muldiv), .is_div(is_div),
        .a(a), .b(b), .adder_sum(sum), .adder_cout(c4),
        .adder_a(md_add_a), .adder_b(md_add_b), .adder_sub(md_add_sub),
        .result(md_out), .div_by_zero(md_dbz), .busy(busy), .done(done)
    );

    result_mux u_mux (
        .opcode(opcode), .sum(sum),
        .and_out(and_out), .or_out(or_out), .xor_out(xor_out), .not_out(not_out),
        .nand_out(nand_out), .nor_out(nor_out), .xnor_out(xnor_out),
        .shl(shl), .shr(shr), .rol(rol), .ror(ror),
        .cmp_out(cmp_out), .dec_out(dec_out), .md_out(md_out), .result(result)
    );

    flag_unit u_flags (
        .opcode(opcode), .arith(arith), .is_shl(is_shl), .is_shr(is_shr),
        .is_mul(is_mul), .is_div(is_div), .result(result), .c3(c3), .c4(c4),
        .shl_bit(shl_bit), .shr_bit(shr_bit), .md_dbz(md_dbz),
        .carry(carry), .zero(zero), .overflow(overflow), .negative(negative), .div_by_zero(div_by_zero)
    );
endmodule