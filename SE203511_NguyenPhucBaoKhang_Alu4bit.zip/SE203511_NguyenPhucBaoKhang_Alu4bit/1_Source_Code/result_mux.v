// ========================================================
// Module Name:  result_mux
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps

module result_mux (
    input  wire [3:0] opcode,
    input  wire [3:0] sum,
    input  wire [3:0] and_out, or_out, xor_out, not_out, nand_out, nor_out, xnor_out,
    input  wire [3:0] shl, shr, rol, ror,
    input  wire [2:0] cmp_out,
    input  wire [7:0] dec_out, md_out,
    output reg  [7:0] result
);
    always @(*) begin
        case (opcode)
            4'b0000, 4'b0001: result = {4'b0000, sum};
            4'b0010: result = {4'b0000, and_out};
            4'b0011: result = {4'b0000, or_out};
            4'b0100: result = {4'b0000, xor_out};
            4'b0101: result = {4'b0000, not_out};
            4'b0110: result = {4'b0000, nand_out};
            4'b0111: result = {4'b0000, nor_out};
            4'b1000: result = {4'b0000, shl};
            4'b1001: result = {4'b0000, shr};
            4'b1010: result = {4'b0000, rol};
            4'b1011: result = {4'b0000, ror};
            4'b1100: result = {5'b00000, cmp_out}; // [2]: A>B, [1]: A==B, [0]: A<B
            4'b1101: result = dec_out;
            4'b1110, 4'b1111: result = md_out;
        endcase
    end
endmodule