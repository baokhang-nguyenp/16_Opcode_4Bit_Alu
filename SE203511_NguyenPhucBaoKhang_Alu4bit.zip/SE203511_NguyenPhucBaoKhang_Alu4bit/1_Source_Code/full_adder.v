// ========================================================
// Module Name:  full_adder
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps

module full_adder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    wire p;
    wire g;

    assign p    = a ^ b;
    assign g    = a & b;
    assign sum  = p ^ cin;
    assign cout = g | (p & cin);

endmodule