// ========================================================
// Module Name:  muldiv_unit
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps
module muldiv_unit (
    input  wire       clk, rst, start, is_div,
    input  wire [3:0] a, b, adder_sum,
    input  wire       adder_cout,
    output wire [3:0] adder_a, adder_b,
    output wire       adder_sub,
    output wire [7:0] result,
    output reg        div_by_zero, busy, done
);
    localparam S_IDLE = 1'b0, S_EXEC = 1'b1;
    reg [3:0] reg_hi, reg_lo, reg_op;
    reg [1:0] step_idx;
    reg       mode_div;

    wire [3:0] shifted_rem = {reg_hi[2:0], reg_lo[3]};
    wire       sub_ok      = reg_hi[3] | adder_cout;

    assign adder_a   = mode_div ? shifted_rem : reg_hi;
    assign adder_b   = reg_op;
    assign adder_sub = mode_div;
    assign result    = {reg_hi, reg_lo};

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            reg_hi <= 0; reg_lo <= 0; reg_op <= 0; step_idx <= 0;
            mode_div <= 0; div_by_zero <= 0; busy <= S_IDLE; done <= 0;
        end else begin
            done <= 1'b0;
            case (busy)
                S_IDLE: begin
                    if (start) begin
                        mode_div <= is_div;
                        step_idx <= 2'b00;
                        if (is_div && (b == 4'b0000)) begin
                            reg_hi <= 0; reg_lo <= 0; reg_op <= 0;
                            div_by_zero <= 1'b1;
                            busy <= S_IDLE;
                            done <= 1'b1;
                        end else begin
                            reg_hi <= 0; reg_lo <= is_div ? a : b; reg_op <= is_div ? b : a;
                            div_by_zero <= 1'b0;
                            busy <= S_EXEC;
                        end
                    end
                end
                S_EXEC: begin
                    if (!mode_div) begin
                        if (reg_lo[0]) {reg_hi, reg_lo} <= {adder_cout, adder_sum, reg_lo[3:1]};
                        else           {reg_hi, reg_lo} <= {1'b0, reg_hi, reg_lo[3:1]};
                    end else begin
                        if (sub_ok) begin
                            reg_hi <= adder_sum; reg_lo <= {reg_lo[2:0], 1'b1};
                        end else begin
                            reg_hi <= shifted_rem; reg_lo <= {reg_lo[2:0], 1'b0};
                        end
                    end

                    if (step_idx == 2'd3) begin
                        busy <= S_IDLE; done <= 1'b1;
                    end else begin
                        step_idx <= step_idx + 2'd1;
                    end
                end
            endcase
        end
    end
endmodule