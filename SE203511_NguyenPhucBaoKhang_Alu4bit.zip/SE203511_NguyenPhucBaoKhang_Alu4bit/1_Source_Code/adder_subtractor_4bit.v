// ========================================================
// Module Name:  adder_subtractor_4bit
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps
module adder_subtractor_4bit (
    input  wire [3:0] a,
    input  wire [3:0] b,
    input  wire       sub,
    output wire [3:0] sum,
    output wire       c3,
    output wire       c4,
    output wire [2:0] cmp_out // Lồng ghép ngõ ra Comparator
);
    wire [3:0] b_x;
    wire [4:0] c;

    // Logic cộng trừ
    assign c[0] = sub;
    assign b_x  = b ^ {4{sub}};

    full_adder fa0 (.a(a[0]), .b(b_x[0]), .cin(c[0]), .sum(sum[0]), .cout(c[1]));
    full_adder fa1 (.a(a[1]), .b(b_x[1]), .cin(c[1]), .sum(sum[1]), .cout(c[2]));
    full_adder fa2 (.a(a[2]), .b(b_x[2]), .cin(c[2]), .sum(sum[2]), .cout(c[3]));
    full_adder fa3 (.a(a[3]), .b(b_x[3]), .cin(c[3]), .sum(sum[3]), .cout(c[4]));

    assign c3 = c[3];
    assign c4 = c[4];

    // Lồng ghép Comparator: [2]=Greater, [1]=Equal, [0]=Less
    assign cmp_out[2] = (a > b);
    assign cmp_out[1] = (a == b);
    assign cmp_out[0] = (a < b);
endmodule