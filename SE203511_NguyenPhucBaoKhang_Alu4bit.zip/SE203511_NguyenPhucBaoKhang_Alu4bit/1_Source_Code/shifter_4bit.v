// ========================================================
// Module Name:  shifter_4bit
// Author:       Nguyen Phuc Bao Khang
// Roll Number:  SE203511
// ========================================================
`timescale 1ns / 1ps

module shifter_4bit (
    input  wire [3:0] a,
    output wire [3:0] shl, shr, rol, ror,
    output wire       shl_out_bit, shr_out_bit
);

    assign shl = {a[2:0], 1'b0};
    assign shr = {1'b0, a[3:1]};
    assign shl_out_bit = a[3];
    assign shr_out_bit = a[0];
    assign rol = {a[2:0], a[3]};
    assign ror = {a[0], a[3:1]};
    
endmodule